# NoxVolt Mini App prototype

This is a static front-end prototype. The buttons and balances are demo behavior; they do not verify ads, Telegram membership, referrals, mining sessions, or make blockchain payouts.

The **About** tab states that NOXV has no active market price at present, records 100,000,000 NOXV as currently minted, and says the project plans to apply for DeDust and STON.fi listings. It also makes clear that a listing or trading availability is not guaranteed.

## Add your channel tasks

1. Open `tasks.js` in a text editor.
2. Replace `window.NOXV_TASKS = [];` with entries like:

```js
window.NOXV_TASKS = [
  {
    title: "Join NoxVolt News",
    description: "Join our Telegram channel",
    url: "https://t.me/your_channel"
  }
];
```

3. Use one entry per channel. Save the file and upload `index.html`, `tasks.js`, and `logo.png` to your website/repository, keeping them in the same folder. Replace the example URL with your real public Telegram channel link.

Users do not get a task submission form. For a live service, keep editing access to the repository private to you and trusted maintainers. Actual membership checks require a Telegram bot added to each channel with enough rights to check membership, plus a backend that verifies users and grants a reward only once.

## Before launch

- Add TON Connect for wallet linking and address verification.
- Integrate a legitimate ad provider and verify completed ad events server-side.
- Keep balances and referral/task/mining reward state on a backend; browser-only balances can be changed by users.
- Implement payouts as TON Jetton transfers, enforce the 500 NOXV minimum server-side, and protect the payout wallet's signing key.
- Define mining session timing and reactivation rules on the backend. The current timer is a visual demo, not blockchain mining.
- Do not promise token value or guaranteed ad income. Publish clear reward, eligibility, and withdrawal rules.
