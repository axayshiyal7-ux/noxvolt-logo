// Owner-maintained task list for the prototype.
// Add only channels you manage or have permission to promote.
// Example task:
// { title: "Join NoxVolt News", description: "Join our Telegram channel", url: "https://t.me/your_channel" }
window.NOXV_TASKS = [];
